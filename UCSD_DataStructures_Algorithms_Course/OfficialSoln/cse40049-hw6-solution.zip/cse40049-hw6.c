/******************************************************************************
 * CSE-40049 - Homework #6
 *
 * File:        cse40049-hw6.c
 * Author:      Ray Mitchell
 * Date:        5/11/2011
 * System:      Intel Core 2 Duo T9300 @ 2.50 GHz
 *              4.00 GB RAM
 *              64-bit Windows 7 Ultimate
 *
 * Program Description:  Implement various functions that perform operations
 *              on a binary tree.
 *
 * Program Output:
                Part a - count_leaves
                    Binary tree:         3 leaves counted
                    Binary search tree:  5 leaves counted

                Part b - count_non_leaves
                    Binary tree:         6 non-leaves counted
                    Binary search tree:  4 non-leaves counted

                Part c - get_height
                    Binary tree:         5 height
                    Binary search tree:  4 height

                Part d - print_pre_order
                    Binary tree:         1 2 4 7 3 5 6 8 9 
                    Binary search tree:  6 4 2 1 3 5 8 7 9 

                Part e - print_in_order
                    Binary tree:         7 4 2 1 5 3 6 8 9 
                    Binary search tree:  1 2 3 4 5 6 7 8 9 

                Part f - print_post_order
                    Binary tree:         7 4 2 5 9 8 6 3 1 
                    Binary search tree:  1 3 2 5 4 7 9 8 6 

                Part g - remove_leaves
                    Binary tree:         
                        Preorder before delete: 1 2 4 7 3 5 6 8 9 
                        Preorder after delete:  1 2 4 3 6 8 
                    Binary search tree:  
                        Preorder before delete: 6 4 2 1 3 5 8 7 9 
                        Preorder after delete:  6 4 2 8 
 *****************************************************************************/
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>

#include "bitree.h"

/*---------------------------------------------------------------------------
 * Part a - Return the number of leaf nodes in the tree
 *---------------------------------------------------------------------------*/
static int count_leaves_(BiTreeNode *n)
{
    if (bitree_is_eob(n))
        return 0;

    if (bitree_is_leaf(n))
        return 1;

    return count_leaves_(bitree_left(n)) + count_leaves_(bitree_right(n));
}

int count_leaves(BiTree *t)
{
    return count_leaves_(bitree_root(t));
}

/*---------------------------------------------------------------------------
 * Part b - Return the number of non-leaf nodes in the tree
 *---------------------------------------------------------------------------*/
int count_non_leaves(BiTree *t)
{
    return bitree_size(t) - count_leaves(t);
}

/*---------------------------------------------------------------------------
 * Part c - Return the height of the tree
 *---------------------------------------------------------------------------*/
static int get_height_(BiTreeNode *n)
{
    int lHeight, rHeight;

    if (bitree_is_eob(n))
        return 0;

    if (bitree_is_leaf(n))
        return 1;

    lHeight = get_height_(bitree_left(n));
    rHeight = get_height_(bitree_right(n));

    return 1 + (lHeight > rHeight ? lHeight : rHeight);
}

int get_height(BiTree *t)
{
    return get_height_(bitree_root(t));
}

/*---------------------------------------------------------------------------
 * Part d - Print the elements of the tree to stdout using a pre-order
 * traversal
 *---------------------------------------------------------------------------*/
static void print_pre_order_(BiTreeNode *n, void (*print)(const void *data))
{
    if (bitree_is_eob(n))
        return;

    print(bitree_data(n));
    print_pre_order_(bitree_left(n), print);
    print_pre_order_(bitree_right(n), print);
}

void print_pre_order(BiTree *t, void (*print)(const void *data))
{
    print_pre_order_(bitree_root(t), print);
}

/*---------------------------------------------------------------------------
 * Part e - Print the elements of the tree to stdout using a in-order
 * traversal
 *---------------------------------------------------------------------------*/
static void print_in_order_(BiTreeNode *n, void (*print)(const void *data))
{
    if (bitree_is_eob(n))
        return;

    print_in_order_(bitree_left(n), print);
    print(bitree_data(n));
    print_in_order_(bitree_right(n), print);
}

void print_in_order(BiTree *t, void (*print)(const void *data))
{
    print_in_order_(bitree_root(t), print);
}

/*---------------------------------------------------------------------------
 * Part f - Print the elements of the tree to stdout using a post-order
 * traversal
 *---------------------------------------------------------------------------*/
static void print_post_order_(BiTreeNode *n,void (*print)(const void *data))
{
    if (bitree_is_eob(n))
        return;

    print_post_order_(bitree_left(n), print);
    print_post_order_(bitree_right(n), print);
    print(bitree_data(n));
}

void print_post_order(BiTree *t, void (*print)(const void *data))
{
    print_post_order_(bitree_root(t), print);
}

/*---------------------------------------------------------------------------
 * Part g - Remove all leaf nodes from the tree
 *---------------------------------------------------------------------------*/
static void remove_leaves_(BiTree *t, BiTreeNode *n)
{
    if (bitree_is_eob(n))
        return;

    /* If left child is leaf, remove it */
    if (!bitree_is_eob(bitree_left(n)) && bitree_is_leaf(bitree_left(n)))
        bitree_rem_left(t, n);

    /* If right child is leaf, remove it */
    if (!bitree_is_eob(bitree_right(n)) && bitree_is_leaf(bitree_right(n)))
        bitree_rem_right(t, n);

    remove_leaves_(t, bitree_left(n));
    remove_leaves_(t, bitree_right(n));
}

void remove_leaves(BiTree *t)
{
    remove_leaves_(t, bitree_root(t));
}

/*-----------------------------------------------------------------------------
 * Test functions
 *---------------------------------------------------------------------------*/
void output_int(const void *key);
int compare_ints(const void *key1, const void *key2);
void fatal_error(const char *message);
void insert_left_child(BiTree *tree, BiTreeNode *parent, const void *data);
void insert_right_child(BiTree *tree, BiTreeNode *parent, const void *data);
void populate_binary_tree(BiTree *tree);
void populate_binary_search_tree(BiTree *tree);

int main() {
    BiTree tree;
    bitree_init(&tree, NULL);

    /* Part a */
    printf("Part a - count_leaves");
    printf("\n    Binary tree:         ");
    populate_binary_tree(&tree);
    printf("%d leaves counted", count_leaves(&tree));
    printf("\n    Binary search tree:  ");
    populate_binary_search_tree(&tree);
    printf("%d leaves counted", count_leaves(&tree));

    /* Part b */
    printf("\n\nPart b - count_non_leaves");
    printf("\n    Binary tree:         ");
    populate_binary_tree(&tree);
    printf("%d non-leaves counted", count_non_leaves(&tree));
    printf("\n    Binary search tree:  ");
    populate_binary_search_tree(&tree);
    printf("%d non-leaves counted", count_non_leaves(&tree));

    /* Part c */
    printf("\n\nPart c - get_height");
    printf("\n    Binary tree:         ");
    populate_binary_tree(&tree);
    printf("%d height", get_height(&tree));
    printf("\n    Binary search tree:  ");
    populate_binary_search_tree(&tree);
    printf("%d height", get_height(&tree));

    /* Part d */
    printf("\n\nPart d - print_pre_order");
    printf("\n    Binary tree:         ");
    populate_binary_tree(&tree);
    print_pre_order(&tree, output_int);
    printf("\n    Binary search tree:  ");
    populate_binary_search_tree(&tree);
    print_pre_order(&tree, output_int);

    /* Part e */
    printf("\n\nPart e - print_in_order");
    printf("\n    Binary tree:         ");
    populate_binary_tree(&tree);
    print_in_order(&tree, output_int);
    printf("\n    Binary search tree:  ");
    populate_binary_search_tree(&tree);
    print_in_order(&tree, output_int);

    /* Part f */
    printf("\n\nPart f - print_post_order");
    printf("\n    Binary tree:         ");
    populate_binary_tree(&tree);
    print_post_order(&tree, output_int);
    printf("\n    Binary search tree:  ");
    populate_binary_search_tree(&tree);
    print_post_order(&tree, output_int);

    /* Part g */
    printf("\n\nPart g - remove_leaves");
    printf("\n    Binary tree:         ");
    populate_binary_tree(&tree);
    printf("\n        Preorder before delete: ");
    print_pre_order(&tree, output_int);
    printf("\n        Preorder after delete:  ");
    remove_leaves(&tree);
    print_pre_order(&tree, output_int);
    printf("\n    Binary search tree:  ");
    populate_binary_search_tree(&tree);
    printf("\n        Preorder before delete: ");
    print_pre_order(&tree, output_int);
    printf("\n        Preorder after delete:  ");
    remove_leaves(&tree);
    print_pre_order(&tree, output_int);

    bitree_destroy(&tree);

    return EXIT_SUCCESS;
}

void output_int(const void *key)
{
    int *pInt = (int *) key;
    printf("%d ", *pInt);
}

int compare_ints(const void *key1, const void *key2)
{
    int *pInt1 = (int *) key1;
    int *pInt2 = (int *) key2;

    if (*pInt1 < *pInt2)
        return -1;
    if (*pInt1 > *pInt2)
        return 1;
    return 0;
}

void fatal_error(const char *message)
{
    fprintf(stderr, message);
    exit(EXIT_FAILURE);
}

void insert_left_child(BiTree *tree, BiTreeNode *parent, const void *data)
{
    if (bitree_ins_left(tree, parent, data) != 0)
        fatal_error("Failed to insert into tree");
}

void insert_right_child(BiTree *tree, BiTreeNode *parent, const void *data)
{
    if (bitree_ins_right(tree, parent, data) != 0)
        fatal_error("Failed to insert into tree");
}

/*
    Populate tree with the following data:
                   1
                 /   \
               2       3
              /       / \
             4       5   6
            /             \
           7               8
                            \
                             9
*/
void populate_binary_tree(BiTree *tree)
{
    static int data[] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
    BiTreeNode *parent;

    bitree_destroy(tree);
    bitree_init(tree, NULL);

    /* ----- Level 1 ----- */
    /* 1 */
    parent = NULL;
    insert_left_child(tree, parent, &data[1]);

    /* ----- Level 2 ----- */
    /* 2 */
    parent = bitree_root(tree);
    insert_left_child(tree, parent, &data[2]);

    /* 3 */
    parent = bitree_root(tree);
    insert_right_child(tree, parent, &data[3]);

    /* ----- Level 3 ----- */
    /* 4 */
    parent = bitree_left(bitree_root(tree));
    insert_left_child(tree, parent, &data[4]);

    /* 5 */
    parent = bitree_right(bitree_root(tree));
    insert_left_child(tree, parent, &data[5]);

    /* 6 */
    parent = bitree_right(bitree_root(tree));
    insert_right_child(tree, parent, &data[6]);

    /* ----- Level 4 ----- */
    /* 7 */
    parent = bitree_left(bitree_left(bitree_root(tree)));
    insert_left_child(tree, parent, &data[7]);
    
    /* 8 */
    parent = bitree_right(bitree_right(bitree_root(tree)));
    insert_right_child(tree, parent, &data[8]);

    /* ----- Level 5 ----- */
    /* 9 */
    parent = bitree_right(bitree_right(bitree_right(bitree_root(tree))));
    insert_right_child(tree, parent, &data[9]);
}

/*
    Populate tree with the following data:
                   6
                 /   \
               4       8
              / \     / \
             2   5   7   9
            / \
           1   3
*/
void populate_binary_search_tree(BiTree *tree)
{
    static int data[] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
    BiTreeNode *parent;

    bitree_destroy(tree);
    bitree_init(tree, NULL);

    /* ----- Level 1 ----- */
    /* 6 */
    parent = NULL;
    insert_left_child(tree, parent, &data[6]);

    /* ----- Level 2 ----- */
    /* 4 */
    parent = bitree_root(tree);
    insert_left_child(tree, parent, &data[4]);

    /* 8 */
    parent = bitree_root(tree);
    insert_right_child(tree, parent, &data[8]);

    /* ----- Level 3 ----- */
    /* 2 */
    parent = bitree_left(bitree_root(tree));
    insert_left_child(tree, parent, &data[2]);

    /* 5 */
    parent = bitree_left(bitree_root(tree));
    insert_right_child(tree, parent, &data[5]);

    /* 7 */
    parent = bitree_right(bitree_root(tree));
    insert_left_child(tree, parent, &data[7]);

    /* 9 */
    parent = bitree_right(bitree_root(tree));
    insert_right_child(tree, parent, &data[9]);

    /* ----- Level 4 ----- */
    /* 1 */
    parent = bitree_left(bitree_left(bitree_root(tree)));
    insert_left_child(tree, parent, &data[1]);

    /* 3 */
    parent = bitree_left(bitree_left(bitree_root(tree)));
    insert_right_child(tree, parent, &data[3]);
}