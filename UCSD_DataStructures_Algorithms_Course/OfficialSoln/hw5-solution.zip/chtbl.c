/******************************************************************************
 * CSE-40049 - Homework #5
 *
 * File:        chtbl.c
 * Author:      Ray Mitchell
 * Date:        5/3/2011
 *
 * Notes:  This implementation has been modified so that it grows the
 * table when the load factor goes above the threshhold.
 *****************************************************************************/
#include <math.h>
#include <stdlib.h>
#include <string.h>

#include "list.h"
#include "chtbl.h"

#define MULT_METHOD_COEFFICIENT 0.618

/* Multiplication method used instead of division method because as number
 * of buckets in hash table grows we cannot guarantee that number of buckets
 * stays prime.  Multiplication method works with non-prime number of buckets
 * while division method does not. */
static int multMethod(const CHTbl *htbl, const void *key) {

    /* Return bucket to which hashed code should be mapped */
    return floor(htbl->buckets * fmod(htbl->h(key) * MULT_METHOD_COEFFICIENT,
            1.0));
}

/* Performance:  O(m * (1 + lf)) */
static int growTable(CHTbl *htbl) {

    List *pOldTable = htbl->table;                                  /* O(1) */
    int oldBuckets = htbl->buckets;                                 /* O(1) */
    ListElmt *pListElmt;
    void *pData;
    int retval;
    int i;

    /* Create and initialize new table */
    htbl->buckets *= htbl->resizeMultiplier;                        /* O(1) */
    if ((htbl->table = (List *)malloc(sizeof(List) * htbl->buckets))/* O(1) */
            == NULL) {
        return 1;                                                   /* O(1) */
    }
    for (i = 0; i < htbl->buckets; ++i) {                           /* O(m) */
        list_init(&htbl->table[i], htbl->destroy);                  /* O(1) */
    }

    /* Move elements from old table to new table */
    for (i = 0; i < oldBuckets; ++i) {                              /* O(m) */

        /* While elements remain in old bucket */
        while ((pListElmt = list_head(&pOldTable[i])) != NULL) {    /* O(lf) */

            /* Remove element from old bucket */
            if ((retval                                             /* O(1) */
                    = list_rem_next(&pOldTable[i], NULL, &pData)) != 0)
                return retval;

            /* Insert element into new table */
            list_ins_next(&htbl->table[multMethod(htbl, pData)],    /* O(1) */
                          NULL,
                          pData);
        }

        /* Destroy old bucket */
        list_destroy(&pOldTable[i]);                                /* O(1) */
    }

    /* Free old table */
    free(pOldTable);                                                /* O(1) */

    return 0;
}

int chtbl_init(CHTbl *htbl, int buckets, int(*h)(const void *key), int(*match)(
        const void *key1, const void *key2), void(*destroy)(void*data),
        double maxLoadFactor, double resizeMultiplier) {

    int i;

    /* Allocate space for the hash table. */
    if ((htbl->table = (List *) malloc(buckets * sizeof(List))) == NULL)
        return -1;

    /* Initialize the buckets. */
    htbl->buckets = buckets;
    for (i = 0; i < htbl->buckets; i++)
        list_init(&htbl->table[i], destroy);

    /* Encapsulate the functions. */
    htbl->h = h;
    htbl->match = match;
    htbl->destroy = destroy;

    /* Store info related to resizing hash table */
    htbl->maxLoadFactor = maxLoadFactor;
    htbl->resizeMultiplier = resizeMultiplier;

    /* Initialize the number of elements in the table. */
    htbl->size = 0;

    return 0;
}

void chtbl_destroy(CHTbl *htbl) {

    int i;

    /* Destroy each bucket. */
    for (i = 0; i < htbl->buckets; i++) {
        list_destroy(&htbl->table[i]);
    }

    /* Free the storage allocated for the hash table. */
    free(htbl->table);

    /* No operations are allowed now, but clear the structure as a
     * precaution. */
    memset(htbl, 0, sizeof(CHTbl));
}

/* Performance:  O(m * (1 + lf)) */
int chtbl_insert(CHTbl *htbl, const void *data) {

    void *temp;
    int bucket, retval;

    /* Do nothing if the data is already in the table. */
    temp = (void *) data;                                           /* O(1) */
    if (chtbl_lookup(htbl, &temp) == 0)                             /* O(1) */
        return 1;

    /* Grow hash table if load factor will go above max */
    if ((double)(htbl->size + 1) / htbl->buckets                    /* O(1) */
            > htbl->maxLoadFactor)
        if ((retval = growTable(htbl)) != 0)             /* O(m * (1 + lf)) */
            return retval;                                          /* O(1) */

    /* Hash the key. */
    bucket = multMethod(htbl, data);                                /* O(1) */

    /* Insert the data into the bucket. */
    if ((retval = list_ins_next(&htbl->table[bucket], NULL, data))  /* O(1) */
            == 0)                                                   
        htbl->size++;                                               /* O(1) */

    return retval;                                                  /* O(1) */
}

int chtbl_remove(CHTbl *htbl, void **data) {

    ListElmt *element, *prev;
    int bucket;

    /* Hash the key. */
    bucket = multMethod(htbl, *data);

    /* Search for the data in the bucket. */
    prev = NULL;

    for (element = list_head(&htbl->table[bucket]); element != NULL; element
            = list_next(element)) {

        if (htbl->match(*data, list_data(element))) {

            /* Remove the data from the bucket. */
            if (list_rem_next(&htbl->table[bucket], prev, data) == 0) {
                htbl->size--;
                return 0;
            } else {
                return -1;
            }
        }

        prev = element;
    }

    /* Return that the data was not found. */
    return -1;
}

int chtbl_lookup(const CHTbl *htbl, void **data) {

    ListElmt *element;
    int bucket;

    /* Hash the key. */
    bucket = multMethod(htbl, *data);

    /* Search for the data in the bucket. */
    for (element = list_head(&htbl->table[bucket]); element != NULL; element
            = list_next(element)) {

        if (htbl->match(*data, list_data(element))) {

            /* Pass back the data from the table. */
            *data = list_data(element);
            return 0;
        }
    }

    /* Return that the data was not found. */
    return -1;
}
