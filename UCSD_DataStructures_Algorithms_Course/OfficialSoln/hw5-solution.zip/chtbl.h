/******************************************************************************
 * CSE-40049 - Homework #5
 *
 * File:        chtbl.h
 * Author:      Ray Mitchell
 * Date:        5/3/2011
 *
 * Notes:  This implementation has been modified so that it grows the
 * table when the load factor goes above the threshhold.
 *****************************************************************************/
#ifndef CHTBL_H
#define CHTBL_H

#include <stdlib.h>

#include "list.h"

/* Define a structure for chained hash tables. */
typedef struct CHTbl_ {

    int buckets;

    int (*h)(const void *key);
    int (*match)(const void *key1, const void *key2);
    void (*destroy)(void *data);

    int size;
    List *table;

    double maxLoadFactor;
    double resizeMultiplier;

} CHTbl;

/* Public Interface */
int chtbl_init(CHTbl *htbl, int buckets, int(*h)(const void *key), int(*match)(
        const void *key1, const void *key2), void(*destroy)(void *data),
        double maxLoadFactor, double resizeMultiplier);

void chtbl_destroy(CHTbl *htbl);

int chtbl_insert(CHTbl *htbl, const void *data);

int chtbl_remove(CHTbl *htbl, void **data);

int chtbl_lookup(const CHTbl *htbl, void **data);

#define chtbl_size(htbl) ((htbl)->size)

#endif
