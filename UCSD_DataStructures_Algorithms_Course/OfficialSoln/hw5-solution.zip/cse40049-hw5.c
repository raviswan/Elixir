/******************************************************************************
 * CSE-40049 - Homework #5
 *
 * File:        cse40049-hw5.c
 * Author:      Ray Mitchell
 * Date:        5/3/2011
 * System:      Intel Core 2 Duo T9300 @ 2.50 GHz
 *              4.00 GB RAM
 *              64-bit Windows 7 Ultimate
 *
 * Program Description:   Modify the chained hash table implementation from
 *              the book so that it auto-resizes when the load factor goes
 *              above a threshhold.
 *
 * Program Output:
        buckets 5, elements 1, lf 0.20, maxlf 0.50, reszmult 2.00
        buckets 5, elements 2, lf 0.40, maxlf 0.50, reszmult 2.00
        buckets 10, elements 3, lf 0.30, maxlf 0.50, reszmult 2.00
        buckets 10, elements 4, lf 0.40, maxlf 0.50, reszmult 2.00
        buckets 10, elements 5, lf 0.50, maxlf 0.50, reszmult 2.00
        buckets 20, elements 6, lf 0.30, maxlf 0.50, reszmult 2.00
        buckets 20, elements 7, lf 0.35, maxlf 0.50, reszmult 2.00
        buckets 20, elements 8, lf 0.40, maxlf 0.50, reszmult 2.00
        buckets 20, elements 9, lf 0.45, maxlf 0.50, reszmult 2.00
        buckets 20, elements 10, lf 0.50, maxlf 0.50, reszmult 2.00
        buckets 40, elements 11, lf 0.28, maxlf 0.50, reszmult 2.00
        buckets 40, elements 12, lf 0.30, maxlf 0.50, reszmult 2.00
        buckets 40, elements 13, lf 0.33, maxlf 0.50, reszmult 2.00
        buckets 40, elements 14, lf 0.35, maxlf 0.50, reszmult 2.00
        buckets 40, elements 15, lf 0.38, maxlf 0.50, reszmult 2.00
        Looking up 1: 0
        Looking up 16: -1
 *****************************************************************************/
#include <stdio.h>
#include <stdlib.h>

#include "chtbl.h"

#define NUM_BUCKETS 5
#define MAX_LOAD_FACTOR 0.5
#define RESIZE_MULTIPLIER 2

int hashInt(const void *pInt) {
    return *((int *) pInt);
}

int matchInts(const void *pInt1, const void *pInt2) {
    return *((const int *)pInt1) == *((const int *)pInt2);
}

void fatalError(const char *pMessage) {
    fprintf(stderr, pMessage);
    exit(EXIT_FAILURE);
}

void insertInt(CHTbl *pTable, const int *pKey) {

    /* Insert */
    if (chtbl_insert(pTable, pKey) != 0) {
        fatalError("Error inserting into hash table");
    }

    /* Display metrics */
    printf("buckets %d, elements %d, lf %4.2f, maxlf %4.2f, reszmult %4.2f\n",
                pTable->buckets,
                pTable->size,
                (double)pTable->size / pTable->buckets,
                pTable->maxLoadFactor,
                pTable->resizeMultiplier);
}

void lookupInt(CHTbl *pTable, int key) {
    int *pKey = &key;

    printf("Looking up %d: %d\n",
            key,
            chtbl_lookup(pTable, (void **)&pKey));
}

int main() {
    CHTbl table;
    int keys[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };
    int i;

    /* Initialize table */
    chtbl_init(&table, NUM_BUCKETS, hashInt, matchInts, NULL,
            MAX_LOAD_FACTOR, RESIZE_MULTIPLIER);

    /* Insert the keys */
    for (i = 0; i < sizeof(keys) / sizeof(keys[0]); ++i) {
        insertInt(&table, &keys[i]);
    }

    /* Verify lookup succeeds for a value inserted before auto-resize */
    lookupInt(&table, 1);

    /* Verify lookup fails for a value not in the hash table */
    lookupInt(&table, 16);

    /* Destroy table */
    chtbl_destroy(&table);

    return EXIT_SUCCESS;
}
